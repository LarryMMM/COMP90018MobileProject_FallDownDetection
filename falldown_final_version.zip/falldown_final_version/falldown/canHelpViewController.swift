//
//  canHelpViewController.swift
//  falldown
//
//  Created by Cong on 8/10/17.
//  Copyright © 2017 Microsoft. All rights reserved.
//

import UIKit

class canHelpViewController: UIViewController {
    
    @IBOutlet weak var watchIDTextField: UITextField!
    
    var userID:String?
    var table:MSTable?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        userID = UserDefaults.standard.string(forKey: "loggedInID")
        
        //connect to table
        let client = MSClient(applicationURLString: "https://falldown.azurewebsites.net")
        table = client.table(withName: "locationData")
        
        //autohide keyborad
        self.hideKeyboardWhenTappedAround()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func canHelpButtonTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func saveButtonTapped(_ sender: Any) {
        let watchID = watchIDTextField.text
        
        print("the watchID is :" + watchID! + "HHHHHH")
        UserDefaults.standard.set(watchID, forKey: "watchID")
        UserDefaults.standard.synchronize()
        
        //update the watch table
        table?.update(["id": watchID, "watcher": userID]) { (result, error) in
            if let err = error {
                print("ERROR ", err)
            } else if let item = result {
                print("Todo Item: ", item["id"])
            }
        }
    }
    
    
    func displayMyAlertMessage(userMessage:String)
    {
        let myAlert = UIAlertController(title:"Sorry", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler:nil);
        myAlert.addAction(okAction);
        self.present(myAlert, animated:true, completion:nil);
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
