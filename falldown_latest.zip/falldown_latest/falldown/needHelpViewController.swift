//
//  needHelpViewController.swift
//  falldown
//
//  Created by Cong on 8/10/17.
//  Copyright © 2017 Microsoft. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import CoreLocation
import CoreData


class needHelpViewController: UIViewController,CLLocationManagerDelegate {

    let manager = CLLocationManager()
    var location = ""
    var latitude: Double = 0.0
    var longitude: Double = 0.0
    var userID:String?
    var table:MSTable?
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let location = locations[0]
        latitude = location.coordinate.latitude
        longitude = location.coordinate.longitude
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //location Setup
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
        
        //connect to table
        let client = MSClient(applicationURLString: "https://falldown.azurewebsites.net")
        table = client.table(withName: "locationData")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool){
       userID = UserDefaults.standard.string(forKey: "loggedInID")!
    }
    
    @IBAction func sendButtonTapped(_ sender: Any) {
        table?.update(["id": userID, "latitude": latitude, "longitude":longitude]) 
        
    }
    
    
    @IBAction func cancelButtonTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
