//
//  helpingViewController.swift
//  falldown
//
//  Created by Cong on 8/10/17.
//  Copyright © 2017 Microsoft. All rights reserved.
//

import UIKit

class helpingViewController: UIViewController {

    @IBOutlet weak var watchIDTextfield: UILabel!
    @IBOutlet weak var userNameDisplay: UILabel!
    @IBOutlet weak var userAgeDisplay: UILabel!
    @IBOutlet weak var userPhoneDisplay: UILabel!
    
    var watchID:String?
    var userTable:MSTable?
    var locationTable:MSTable?
    var latitude:String?
    var longitude:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let client = MSClient(applicationURLString: "https://falldown.azurewebsites.net")
        userTable = client.table(withName: "userData")
        locationTable = client.table(withName: "locationData")
        
        //keep active
        var timer = Timer.scheduledTimer(timeInterval: 0.4, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool){
        watchIDTextfield.text = UserDefaults.standard.string(forKey: "watchID")
        watchID = UserDefaults.standard.string(forKey: "watchID")
        
        let predicate = NSPredicate(format:"id == %@", watchID!)
        userTable!.read(with: predicate) { (result, error) in
            if let err = error {
                print("ERROR ", err)
            } else if let items = result?.items {
                for item in items {
                    self.userNameDisplay.text = item["name"] as? String
                    self.userAgeDisplay.text = item["Age"] as? String
                    self.userPhoneDisplay.text = item["phone"] as? String
                }
            }
        }
        
    }
    
    @objc func update(){
        watchID = UserDefaults.standard.string(forKey: "watchID")
        let predicate = NSPredicate(format:"id == %@", watchID!)
        locationTable!.read(with: predicate) { (result, error) in
            if let err = error {
                print("ERROR ", err)
            } else if let items = result?.items {
                for item in items {
                    if(item["latitude"] != nil){
                        print(item["latitude"])
                        let latitude = item["latitude"]
                        print(item["longitude"])
                        let longitude = item["longitude"]
                  
                        UserDefaults.standard.set(latitude, forKey: "latitude")
                        UserDefaults.standard.set(longitude, forKey: "longitude")
                        UserDefaults.standard.synchronize()
                        
                        self.performSegue(withIdentifier: "showmapView", sender: self)
                        
                   
                    }
                    
                }
            }
        }
        
    }
    
    @IBAction func cancelButtonTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
